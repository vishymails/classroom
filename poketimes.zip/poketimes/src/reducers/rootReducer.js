const initState = {
  posts: []
}

const rootReducer = (state = initState, action) => {
  return state;
}

export default rootReducer