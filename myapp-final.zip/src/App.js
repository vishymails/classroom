import React, { Component } from 'react';
import Kudos from './Kudos';
import Ninjas from './Ninjas';
import Ninjas1 from './Ninjas1';
import Ninjas2 from './Ninjas2';
import Addninja from './AddNinja';



class App extends Component {
  names = ['ibm', 'sun', 'oracle', 'apache'];
  

  state = {
    ninjas: [ 
      {name: 'Ram', age:30, belt: 'black', id:1},
      {name: 'Krishna', age:31, belt: 'green', id:2},
      {name: 'BalDev', age:25, belt: 'pink', id:3},
      {name: 'Rukma', age:28, belt: 'yellow', id:4}
    ]
  }
  addNinja = (ninja) => {
    ninja.id = Math.random();
    let ninjas = [...this.state.ninjas, ninja];
    this.setState({
      ninjas: ninjas
    });

  }

  render() {
    return (
      <div className="App">
        <h1>My first React app</h1>
        <p>Welcome :)</p>

        <ul>
          {
            this.names.map(function(name, index){
              return <li key={index}>{name}</li>;
            })
          }
        </ul>
          
          <h3>Form Example (component Communication)</h3>
            <Addninja addNinja={this.addNinja} />

          <Kudos />

          <h3> Property based component example</h3>

          <Ninjas name="Ram" age="30" belt="green" />
          <Ninjas name="Krishna" age="33" belt="black" />

          <h3> Component and state Example</h3>
          <Ninjas1 ninjas1={this.state.ninjas} />


          <h3> Component and state Example</h3>
          <Ninjas2 ninjas={this.state.ninjas} />

          
      </div>
    );
  }
}

export default App;
