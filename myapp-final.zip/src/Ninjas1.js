import React, {Component} from 'react';
import './themes.css'

class Ninjas1 extends Component{
    render(){
        const { ninjas1 } = this.props;
        const ninjaList = ninjas1.map(ninja =>{
            return (
                 <div className = "ninja" key = {ninja.id}>
                <div> Name : { ninja.name }</div>
                <div> Age : { ninja.age }</div>
                <div> Belt : { ninja.belt }</div>
            </div>
            )
        });
        return (
            <div className= "ninja-list">
                {ninjaList}
            </div>
        )};
};
export default Ninjas1;