import React, {Component} from 'react';
import './themes.css';

const Ninjas2 = ({ninjas}) => {
    return (
 <div className= "ninja-list">
{
    ninjas.map(ninja =>{
            return (
                 <div className = "ninja" key = {ninja.id}>
                <div> Name : { ninja.name }</div>
                <div> Age : { ninja.age }</div>
                <div> Belt : { ninja.belt }</div>
            </div>
            )  
    })        
}
 </div>
    );
}
export default Ninjas2;