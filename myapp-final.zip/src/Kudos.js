import React, {Component} from 'react';

class Kudos extends Component{
    render(){
        return (
        <div className="kudos">
            <div>Company : ITC Infotech</div>
            <div> Training: MERN Stack</div>        
       </div>
        )};
};

export default Kudos;